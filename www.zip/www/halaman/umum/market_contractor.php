<div data-page="market_contractor" class="page navbar-fixed">
    <div class="navbar" style="background-color:#088378;">
        <div class="navbar-inner ">
            <div class="left sliding">
                <a href="#" class="open-panel link icon-only"><i class="icon icon-bars"></i></a>
            </div>
            <div class="center font-standard">
                Terra Contractor Service
            </div>
            <div class="right sliding"> 
                <img id="mc_tambahproduk" src="img/menu_icon/icon_menu_favourite_light.svg" width="40%" alt="" style="vertical-align:middle;margin-right: 0.5em;"/>
                <img id="mc_refreshproduk" src="img/menu_icon/icon refresh light.svg"  width="40%" alt="" style="vertical-align:middle;margin-right: 0.3em"/>
            </div>
        </div>
    </div>
    <a href="halaman/umum/market_contractor-filter.php"  class="floating-button"  style="background-color: #088378;" id="float_marketc">
    <i class="fa fa-sliders dav-cterra"></i>
      </a>

    <form data-search-list=".list-block-search" data-search-in=".item-title" class="searchbar searchbar-init" style="background-color:#088378;">
        <div class="searchbar-input">
        <input type="search" placeholder="Search" id="searchlist_jasa"><a href="#" class="searchbar-clear"></a>
        </div><a href="#" class="searchbar-cancel">Cancel</a>
    </form>
     
      <!-- Search Bar overlay -->
      <div class="searchbar-overlay"></div>

    <style></style>
    <div class="page-content">
    <div class="content-block-title"><div id="cap-market_contructor">Total Data 0 Data.</div></div>
                                  
        <div class="prductlist  content-block">
        <div id="isi-market_contructor"> </div> <!-- end div productlists market -->
           <!--  <div class="row">
                <div class="card dav-card   col-50" >
                    <div class="card-content"> 
                        <div class="banner productblock"><a href="#" data-popover=".popover-lp_zoom" data-foto="" class="link open-popover" id="listp_popover">
                            <img src="img/aw.jpg" class="col-100 dav-myimage" alt="banner1"></a>
                        </div>
                        <div class="dav-marketcontent">
                            Olah Lahan <i class="fa fa-arrow-right dav-cterra"></i> Traktor 2W / 4W <br/>
                            Bajak Sawah Pak Ade Iseki
                            <br/><font class="dav-fharga">Rp 260.000 / ha</font>
                            <br/><font class="dav-fkota">Surabaya</font><br/>
                            <font class="dav-frating" id="dav-frating">
                            <i class="fa fa-star dav-crating"></i> 
                            <i class="fa fa-star dav-crating"></i>
                            <i class="fa fa-star dav-crating"></i>
                            <i class="fa fa-star dav-crating"></i>
                            <i class="fa fa-star-half-o dav-crating"></i>
                            (28)
                            </font> 
                        </div>
                    </div>
                </div> 

                <div class="card dav-card   col-50" >
                    <div class="card-content"> 
                        <div class="banner productblock"><a href="#" data-popover=".popover-lp_zoom" data-foto="" class="link open-popover" id="listp_popover">
                            <img src="img/aw.jpg" class="col-100 dav-myimage" alt="banner1"></a>
                        </div>
                        <div class="dav-marketcontent">
                            Olah Lahan <i class="fa fa-arrow-right dav-cterra"></i> Traktor 2W / 4W <br/>
                            Bajak Sawah Pak Ade Iseki
                            <br/><font class="dav-fharga">Rp 260.000 / ha</font>
                            <br/><font class="dav-fkota">Surabaya</font><br/>
                            <font class="dav-frating" id="dav-frating">
                           &nbsp;
                            </font> 
                        </div>
                    </div>
                </div> 

                <div class="card dav-card   col-50" >
                    <div class="card-content"> 
                        <div class="banner productblock"><a href="#" data-popover=".popover-lp_zoom" data-foto="" class="link open-popover" id="listp_popover">
                            <img src="img/aw.jpg" class="col-100 dav-myimage" alt="banner1"></a>
                        </div>
                        <div class="dav-marketcontent">
                            Olah Lahan <i class="fa fa-arrow-right dav-cterra"></i> Traktor 2W / 4W <br/>
                            Bajak Sawah Pak Ade Iseki
                            <br/><font class="dav-fharga">Rp 260.000 / ha</font>
                            <br/><font class="dav-fkota">Surabaya</font><br/>
                            <font class="dav-frating" id="dav-frating">
                            <i class="fa fa-star dav-crating"></i> 
                            <i class="fa fa-star dav-crating"></i>
                            <i class="fa fa-star dav-crating"></i>
                            <i class="fa fa-star dav-crating"></i>
                            <i class="fa fa-star-half-o dav-crating"></i>
                            (28)
                            </font> 
                        </div>
                    </div>
                </div> 

            </div> -->  <!-- end div isi row --> 




        <div class='pagination' id="pagemarket_contractor">
        <!-- <a href='#' id='paging-produkseller' data-angka='2' class="active">1</a> -->
        </div>
          <!-- awal preloader -->
            <div class="dav-outter" id="preloader-mc">
                <div class="dav-loading">
                <font style="margin:0px auto;text-align: center;">Loading</font><br>
                <span class="preloader" style=""></span>
                </div>
            </div>
        <!-- preloader -->
        </div>
    </div>
</div>

