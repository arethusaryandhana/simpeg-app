<div data-page="market_contractor-filter" class="page navbar-fixed">

    <div class="navbar" style="background-color:#088378;">
        <div class="navbar-inner ">
        <div class="left sliding">
        <a href="#" class="back link icon-only"><i class="icon icon-close"></i></a>
        </div>
        <div class="center">
        <b>Filter</b>
        </div>
        <div class="right sliding"> 

        </div>
        </div>
    </div>
        <div class="toolbar toolbar-bottom" style="background-color: #C1E5CC;font-weight: bold;box-shadow: 1px 1px 1px 0px  rgba(0,0,0,0.4);">
            <div class="toolbar-inner">
            <a href="#" class="link " id="mf_action"
            style="width: 80%;height: 80%;margin: 0px auto;background-color: #088378;font-weight: 420;border-radius: 4px;"> Terapkan Filter</a>
            </div>
        </div>
    <div class="page-content">
        <div class="list-block content-block">

            <ul style="margin-top: -13px;">
                         
                 <h class="dav-fontorder">Jenis Jasa</h> 
                <div class="swiper-container swiper-3">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="chip chipfilterjasa dav-chipfilter" id="b8" data-urut='b8' data-idjasa='8' >
                            <div class="chip-label">Semua Jasa</div>
                            </div>
                        </div>

                        <div class="swiper-slide">
                            <div class="chip chipfilterjasa dav-chipfilter" id="b1" data-urut='b1' data-idjasa='1' >
                            <div class="chip-label">Olah Lahan</div>
                            </div>
                        </div>

                        <div class="swiper-slide" style="">
                            <div class="chip chipfilterjasa  dav-chipfilter" id="b2" data-urut='b2' data-idjasa='2'>
                            <div class="chip-label">Penanaman</div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="chip chipfilterjasa  dav-chipfilter" id="b3" data-urut='b3' data-idjasa='3'>
                            <div class="chip-label">Perawatan</div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="chip chipfilterjasa dav-chipfilter" id="b4" data-urut='b4' data-idjasa='4'>
                            <div class="chip-label">Jasa Panen</div>
                            </div>
                        </div>
                         <div class="swiper-slide">
                            <div class="chip chipfilterjasa dav-chipfilter" id="b5" data-urut='b5' data-idjasa='5'>
                            <div class="chip-label">Penggilingan</div>
                            </div>
                        </div>
                         <div class="swiper-slide">
                            <div class="chip chipfilterjasa dav-chipfilter" id="b6" data-urut='b6' data-idjasa='6'>
                            <div class="chip-label">Lainnya</div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                  <h class="dav-fontorder">Jenis Sub Jasa</h> 
                <li>
                <a href="#" class="item-link smart-select" data-open-in="picker">
                <select name="fruits" id="mc-filter">
                </select>
                <div class="item-content">
                <div class="item-inner">
                <!-- <div class="item-title">Kategori</div> -->
                </div>
                </div>
                </a>
                </li>

              <!--<h class="dav-fontorder">Belum dipake</h> 
                  <li>
                  <a href="#" class="item-link smart-select" data-open-in="picker">
                  <select name="fruits" id="pt_kategori">
                  <option value="Lelang" selected>Lelang</option>
                  <option value="Biasa" disabled>Jual Biasa</option>
                  </select>
                  <div class="item-content">
                  <div class="item-inner">
                  </div>
                  </div>
                  </a>
                  </li> -->
            </ul>

        </div>

            <div class="dav-outter" id="preloader-filter">
            <div class="dav-loading">
                <font style="margin:0px auto;text-align: center;float: center;">Loading</font><br>
                <span class="preloader" style=""></span>
            </div>
            </div>
           
    </div>
</div>
