<div data-page="messages_home" class="page navbar-fixed">
    <div class="navbar" style="background-color:#088378;">
        <div class="navbar-inner ">
            <div class="left sliding">
                <a href="halaman/home.php" class="link icon-only"><i class="icon icon-back"></i></a>
            </div>
            <div class="center font-standard"><b>Messages</b></div>
            <div class="right"></div>
        </div>
    </div>  
    <div class="page-content" style="background-image: linear-gradient( #FFFFFF, #088378);">
        <div class="list-block media-list">
            <ul>
            <div id="isihomem"></div>


            <!-- <li class="swipeout">
            <a href="#" id="itemchat" class="item-link item-content swipeout-content">
            <div class="item-media"><img src="img/pic1.png" width="50"  alt=""/></div>
            <div class="item-inner">
            <div class="item-title-row">
              <div class="item-title">New tones here</div>
              <div class="item-after">$22 asdas</div>
            </div>

            <div class="item-text">Selamat siang</div>
            </div>  </a>
            <div class="swipeout-actions-right"><a href="#" data-confirm="Are you sure you want to delete this item?" class="swipeout-delete">Delete</a></div>

            </li> -->


            </ul>
        </div>

    </div>
</div>
