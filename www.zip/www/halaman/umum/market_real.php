<div data-page="market_real" class="page navbar-fixed">
<div class="navbar" style="background-color:#088378;">
<div class="navbar-inner ">
<div class="left sliding"><a href="#" class="open-panel link icon-only"><i class="icon icon-bars"></i></a></div>
<div class="center font-standard">Terra Market</div>
<div class="right sliding"> 
<img id="dp_refreshproduk" src="img/menu_icon/icon refresh light.svg" width="40%" alt="" style="vertical-align:middle;margin-right: 0.5em;"/>&nbsp;
<img id="dp_tambahproduk" src="img/menu_icon/icon_menu_plus_light.svg"  width="40%" alt="" style="vertical-align:middle;margin-right: 0.3em"/>
</div></div></div>

<form data-search-list=".list-block-search" data-search-in=".item-title" class="searchbar searchbar-init" style="background-color:#088378;">
<div class="searchbar-input">
<input type="search" placeholder="Search" id="searchlistmyproduk"><a href="#" class="searchbar-clear"></a>
</div><a href="#" class="searchbar-cancel">Cancel</a>
</form>
 
  <!-- Search Bar overlay -->
  <div class="searchbar-overlay"></div>
<!--   <div class="toolbar tabbar" style="background-color:#088378;height:120px;position:relative;">
    <div class="toolbar-inner ">
      <div class="item-content userprofile hundred-percent" style="height:auto;">
        <div class="item-media" style="padding-left:5%;"><img src="img/menu_icon/photo_profile_light.svg" id="imghome" width="50" alt=""/></div>
        <div class="item-inner" style="padding-top:5%;">
          <div class="item-title-row" style="">
            <div class="item-title font-color-light font-standard" id="greeting">Nama Profil</div>
          </div>
          <div class="item-subtitle font-color-light font-standard" id="userlogin">Lokasi : Surabaya<br/>Member sejak Maret 2019</div>
        </div>
         <div class="item-inner" style="width:20%;padding-top:5%;">
            <div class="item-title font-color-light font-standard"><img src="img/menu_icon/icon_create_light.svg" alt=""/></div>
        </div>
      </div>
    </div>
  </div> -->
<style></style>
<div class="page-content bg-satu">
<div class="content-block-title"><div id="cap-produkseller">Total Data 0 Data.</div></div>
                              
<div class="prductlist  content-block">
<div id="isi-marketterra">
   <div class="row">
  <div class="card  tablet-50 col-50">
<div class="card-content"> 
<div class="banner productblock"><a href="#" data-popover=".popover-lp_zoom" data-foto="" class="link open-popover" id="listp_popover"><img src="img/aw.jpg" class="col-100 myimage" alt="banner1"></a></div>
<div class="content-block productdata ">
<h2 class="maintitle col-100" style="font-size:13px;">Nama Produk</h2>
<font class="col-100" style="font-size:13px;margin-bottom:13px;">Rp. 50,000</font>
<div class="item-text fontku">Est Hasil : ' . $r['estimasi_hasil'] ." " . $r['satuan'] .'</div>
<div class="item-text fontku">Luas Lahan : ' . $r['luas_lahan'] .' m<sup>2</sup></div>

</div>

</div>
<p class="buttons-row"><button id="lp_btnlihat" data-id_penawaran ="" data-idrencana ="" class="bkeren" style="margin:0px auto;" ><b>Detail</b></button></p>
</div> 

 <div class="card  tablet-50 col-50">
<div class="card-content"> 
<div class="banner productblock"><a href="#" data-popover=".popover-lp_zoom" data-foto="" class="link open-popover" id="listp_popover"><img src="img/aw.jpg" class="col-100 myimage" alt="banner1"></a></div>
<div class="content-block productdata ">
<h2 class="maintitle col-100" style="font-size:13px;">Nama Produk</h2>
<font class="col-100" style="font-size:13px;margin-bottom:13px;">Rp. 50,000</font>
<div class="item-text fontku">Est Hasil : ' . $r['estimasi_hasil'] ." " . $r['satuan'] .'</div>
<div class="item-text fontku">Luas Lahan : ' . $r['luas_lahan'] .' m<sup>2</sup></div>

</div>
</div>
<p class="buttons-row"><button id="lp_btnlihat" data-id_penawaran ="" data-idrencana ="" class="bkeren" style="margin:0px auto;" ><b>Detail</b></button></p>
</div> 

      <div class="card  tablet-50 col-50">
      <div class="card-content"> 
      <div class="banner productblock"> <img src="img/product2.jpg" class="col-100 myimage" alt="banner1"> </div>
      <div class="content-block productdata ">
      <h2 class="maintitle col-100 ">Car</h2>
      <font class="col-100" style="font-size:13px;margin-bottom:10px;">Rp. 50,000</font>
      <h3 class="col-100">$ 600</h3>
      <div class="item-subtitle star color-amber ">★★★★★</div>
      <div class="clear"></div>
      </div>
      <div class="clear"></div>
      </div>
      </div>

</div><!-- end div isi market --> </div> <!-- end div productlists market -->



<div class='pagination' id="pageprodukseller">
<!-- <a href='#' id='paging-produkseller' data-angka='2' class="active">1</a> -->
</div>
  
   
    
</div>
</div>
