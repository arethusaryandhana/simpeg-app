  <div data-page="s_produkzedit_harga" class="page navbar-fixed ">
  <div class="navbar" style="background-color:#088378;">
  <div class="navbar-inner">
  <div class="left sliding"><a href="#" class="link back icon-only"><i class="icon icon-back"></i></a></div>
  <div class="center"><b>Harga Produk</b></div>
  <div class="right"> 
  <a href="#" id="pt_simpanharga" style="color:white;margin-right: 1.3em;font-size: 16px;">Simpan</a></div>
  </div>
  </div>
  <div class="page-content" >
  <div class="list-block" style="margin-top:20px;">

  <ul>


    <li>
    <div class="item-content">
    <div class="item-media">Rp</div>
    <div class="item-inner">
    <div class="item-title" style="margin-left: -56px;.">Harga</div>
    <div class="item-input">
    <input type="text" class="comi" id="zpt_harga" placeholder="Harga Produk Anda">
    </div>
    </div>
    </div>
    </li>

     <li class="lelang">
    <div class="item-content">
    <div class="item-media">Rp</div>
    <div class="item-inner">
    <div class="item-title" style="margin-left: -56px;.">Kelipatan Bid</div>
    <div class="item-input">
    <input type="text" class="comi" id="zpt_bid" placeholder="Masukan Kelipatan Bid">
    </div>
    </div>
    </div>
    </li>
  </ul>

  </div>
  </div>
  </div>
