<div data-page="s_produkdaftar" class="page navbar-fixed">
<div class="navbar" style="background-color:#088378;">
<div class="navbar-inner ">
<div class="left sliding"><a href="#" class="open-panel link icon-only"><i class="icon icon-bars"></i></a></div>
<div class="center font-standard">Daftar Produk</div>
<div class="right sliding"> 
<img id="dp_refreshproduk" src="img/menu_icon/icon refresh light.svg" width="40%" alt="" style="vertical-align:middle;margin-right: 0.5em;"/>&nbsp;
<img id="dp_tambahproduk" src="img/menu_icon/icon_menu_plus_light.svg"  width="40%" alt="" style="vertical-align:middle;margin-right: 0.3em"/>
</div></div></div>

<form data-search-list=".list-block-search" data-search-in=".item-title" class="searchbar searchbar-init" style="background-color:#088378;">
<div class="searchbar-input">
<input type="search" placeholder="Search" id="searchlistmyproduk"><a href="#" class="searchbar-clear"></a>
</div><a href="#" class="searchbar-cancel">Cancel</a>
</form>
 
  <!-- Search Bar overlay -->
  <div class="searchbar-overlay"></div>
<!--   <div class="toolbar tabbar" style="background-color:#088378;height:120px;position:relative;">
    <div class="toolbar-inner ">
      <div class="item-content userprofile hundred-percent" style="height:auto;">
        <div class="item-media" style="padding-left:5%;"><img src="img/menu_icon/photo_profile_light.svg" id="imghome" width="50" alt=""/></div>
        <div class="item-inner" style="padding-top:5%;">
          <div class="item-title-row" style="">
            <div class="item-title font-color-light font-standard" id="greeting">Nama Profil</div>
          </div>
          <div class="item-subtitle font-color-light font-standard" id="userlogin">Lokasi : Surabaya<br/>Member sejak Maret 2019</div>
        </div>
         <div class="item-inner" style="width:20%;padding-top:5%;">
            <div class="item-title font-color-light font-standard"><img src="img/menu_icon/icon_create_light.svg" alt=""/></div>
        </div>
      </div>
    </div>
  </div> -->
<style></style>
<div class="page-content bg-satu">
<div class="content-block-title"><div id="cap-produkseller">Total Data 0 Data.</div></div>
                              
<!-- <div class="card" style="font-weight: bold;">
<div class="card-content">
<div class="list-block media-list">
<ul>
<li class="item-content">
<div class="item-media">
<img src="img/padi.jpg" width="80" height="80" style="border-radius: 0;">
</div>
<div class="item-inner">
<div class="item-title">Yellow Submarine 
<font style="color:#088378;float:right;" id="f_nama"><i class="fa fa-gear" aria-hidden="true"></i></font>
</div>
<div class="item-text" style="font-size: 15px;color:#088378;font-weight: bold;"><font id="pro-kategori">Lelang<br/>
<i class="fa fa-clock-o" aria-hidden="true"> : </i> 500d 22h 51m 5s</font></div>
<div class="item-text" style="font-size: 16px;color:#FF6400;">Rp. 50,000</div>
</div>
</li>
</ul>
</div></div></div>    -->
    
<!-- <div class="card">
<div class="card-content">
<div class="list-block media-list">
<ul>
<li class="item-content">
<div class="item-media">
<img src="img/padi.jpg" width="80" height="80" style="border-radius: 0;">
</div>
<div class="item-inner">
<div class="item-title">Yellow Submarine 
<font style="color:#088378;float:right;" id="f_nama"><i class="fa fa-gear" aria-hidden="true"></i></font>
</div>
<div class="item-text" style="font-size: 16px;margin-top:10px;color:#FF6400;">Rp. 50,000</div>
</div>
</li>
</ul>
</div></div></div>  -->

<div id="isi-produkseller"></div>
<div class='pagination' id="pageprodukseller">
<!-- <a href='#' id='paging-produkseller' data-angka='2' class="active">1</a> -->
</div>
  
   
    
</div>
</div>
