  <div data-page="s_produkzedit_satuan" class="page navbar-fixed ">
  <div class="navbar" style="background-color:#088378;">
  <div class="navbar-inner">
  <div class="left sliding"><a href="#" class="link back icon-only"><i class="icon icon-back"></i></a></div>
  <div class="center"><b>Satuan & Kuantitas</b></div>
  <div class="right"> 
  <a href="#" id="pt_simpansatuan" style="color:white;margin-right: 1.3em;font-size: 16px;">Simpan</a></div>
  </div>
  </div>
  <div class="page-content" > 
  <div class="list-block" style="margin-top:20px;">

  <ul>


     <li>
      <!-- Smart select, will be opened in Picker -->
      <a href="#" class="item-link smart-select" data-open-in="picker">
          <select name="fruits" id="zpt_satuan">
            <option value="Ton" >Ton</option>
            <!-- <option value="Kwintal" >Kwintal</option> -->
          <option value="Kg" selected>Kilogram</option>
          <!-- <option value="Gram" >Gram<moption> -->
        </select>
        <div class="item-content">
          <div class="item-inner">
            <div class="item-title">Satuan</div>
          </div>
        </div>
      </a>
    </li>  

     <li class="lelang">
    <div class="item-content">
    <div class="item-inner">
    <div class="item-title">Kuantitas</div>
    <div class="item-input">
    <input type="number" id="zpt_qty" placeholder="Masukan Total Produk">
    </div>
    </div>
    </div>
    </li>
  </ul>

  </div>
  </div>
  </div>
