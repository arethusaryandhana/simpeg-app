  <div data-page="s_produkzedit_masalelang" class="page navbar-fixed ">
  <div class="navbar" style="background-color:#088378;">
  <div class="navbar-inner">
  <div class="left sliding"><a href="#" class="link back icon-only"><i class="icon icon-back"></i></a></div>
  <div class="center"><b>Masa Lelang</b></div>
  <div class="right"> 
  <a href="#" id="pt_simpanwaktu" style="color:white;margin-right: 1.3em;font-size: 16px;">Simpan</a></div>
  </div>
  </div>
  <div class="page-content" > 


    <div style="margin-top:-5px;" class="list-block">

      <ul>
         <h2 style=" padding-left: 15px;color:#088378;" class="f18" ></span><i class="fa fa-calendar-plus-o" aria-hidden="true"></i> Waktu Mulai : </h2>
        <li>
          <div class="item-content">
            <div class="item-inner">
              <div class="item-input">
                <input type="text" placeholder="Date Time" readonly="readonly" id="ks-picker-date"/>
              </div>
            </div>
          </div>
        </li>
      </ul>
      <div id="ks-picker-date-container"></div>


    </div>
    

       <h2 style=" padding-left: 15px;color:#088378;" class="f18" ></span><i class="fa fa-calendar-plus-o" aria-hidden="true"></i>Waktu Selesai : </h2>
    <div style="margin-top:-10px;" class="list-block">
      <ul>
        <li>
          <div class="item-content">
            <div class="item-inner">
              <div class="item-input">
                <input type="text" placeholder="Date Time" readonly="readonly" id="ks-picker-date2"/>
              </div>
            </div>
          </div>
        </li>
      </ul>
    </div>
    <div id="ks-picker-date-container2"></div>
  </div>


  </div>
  </div>
