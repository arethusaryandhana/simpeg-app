  <div data-page="s_produkzedit_deskripsi" class="page navbar-fixed ">
  <div class="navbar" style="background-color:#088378;">
  <div class="navbar-inner">
  <div class="left sliding"><a href="#" class="link back icon-only"><i class="icon icon-back"></i></a></div>
  <div class="center"><b>Deskripsi Produk</b></div>
  <div class="right"> 
  <a href="#" id="pt_simpandesk" style="color:white;margin-right: 1.3em;font-size: 16px;">Simpan</a></div>
  </div>
  </div>
  <div class="page-content" >
      <div class="list-block" style="margin-top:20px;">

  <ul>
  <li>
  <div class="item-content">
  <div class="item-inner">
  <div class="item-title  label " style="font-size: 14px;">Deskrispi Produk</div>
  <div class="item-input">
  <textarea id="zpt_deksripsi" placeholder="Tuliskan Keterangan Deskripsi Produk Anda" resizeable></textarea>
  </div>
  </div>
  </div>
  </li>
  </ul>

  </div>
  </div>
  </div>
