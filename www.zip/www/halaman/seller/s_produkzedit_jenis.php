  <div data-page="s_produkzedit_jenis" class="page navbar-fixed ">
  <div class="navbar" style="background-color:#088378;">
  <div class="navbar-inner">
  <div class="left sliding"><a href="#" class="link back icon-only"><i class="icon icon-back"></i></a></div>
  <div class="center"><b>Jenis Produk</b></div>
  <div class="right"> 
  <a href="#" id="pt_simpanjenis" style="color:white;margin-right: 1.3em;font-size: 16px;">Simpan</a></div>
  </div>
  </div>
  <div class="page-content" >
  <div class="list-block">
  <ul style="">
     <h2 style=" padding-left: 10px;padding-top: 10px;" class="f18"></span>Jenis Produk</h2>
    <!-- Single radio input -->
    <li>
      <label class="label-radio item-content">
        <!-- Checked by default -->
        <input type="radio" name="zmy-radio" id="zmy-radio" value="1" checked="checked">
        <div class="item-media">
          <i class="icon icon-form-radio"></i>
        </div>
        <div class="item-inner">
          <div class="item-title">Beras</div>
        </div>
      </label>
    </li>
    <!-- Another radio input -->
    <li>
      <label class="label-radio item-content">
        <input type="radio" name="zmy-radio"  id="zmy-radio" value="2">
        <div class="item-media">
          <i class="icon icon-form-radio"></i>
        </div>
        <div class="item-inner">
          <div class="item-title">Beras Broken</div>
        </div>
      </label>
    </li>
        <li>
      <label class="label-radio item-content">
        <input type="radio" name="zmy-radio"  id="zmy-radio" value="3">
        <div class="item-media">
          <i class="icon icon-form-radio"></i>
        </div>
        <div class="item-inner">
          <div class="item-title">Gabah</div>
        </div>
      </label>
    </li>
        <li>
      <label class="label-radio item-content">
        <input type="radio" name="zmy-radio"  id="zmy-radio" value="4">
        <div class="item-media">
          <i class="icon icon-form-radio"></i>
        </div>
        <div class="item-inner">
          <div class="item-title">Katul</div>
        </div>
      </label>
    </li>
       <li>
      <label class="label-radio item-content">
        <input type="radio" name="zmy-radio"  id="zmy-radio" value="5">
        <div class="item-media">
          <i class="icon icon-form-radio"></i>
        </div>
        <div class="item-inner">
          <div class="item-title">Lainnya</div>
        </div>
      </label>
    </li>

          <li class="zgabah">
      <!-- Smart select, will be opened in Picker -->
      <a href="#" class="item-link smart-select" data-open-in="picker">
          <select name="fruits" id="zpt_gabah">
          <option value="GKG" selected>GKG</option>
          <option value="GKP">GKP (Kadar Air <= 14%)</option>
        </select>
        <div class="item-content">
          <div class="item-inner">
            <div class="item-title">Jenis Gabah</div>
          </div>
        </div>
      </a>
    </li>  
  </ul>
</div>   
  </div>
  </div>
