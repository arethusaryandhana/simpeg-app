<div data-page="s_produktambah3" class="page navbar-fixed ">
  <div class="navbar" style="background-color:#088378;">
    <div class="navbar-inner">
        <div class="left sliding"><a href="#" class="link back icon-only"><i class="icon icon-back"></i></a></div>
        <div class="center"><b>Tambah Product</b></div>
        <div class="right"> 
          <a href="#" id="pt_final" style="color:white;margin-right: 1.3em;font-size: 16px;">simpan</a></div>
    </div>
  </div>
  <div class="page-content" >

     <div class="list-block" style="margin-top:-1px;">
        <h2 style=" padding-left: 10px;" class="f18"></span>Detail Produk<font id="f_kategoripr"></font></h2>
    
  

        <ul style="margin-top:-10px;">

        <li class="item-content" style="border-bottom:0.5px solid #C8B9C2;">
        <div class="item-inner">
        <div class="item-title"><a href="#" style="color:black;" id="edit_fproduk" data-kat="produk-jenis">Jenis Produk
        <font id="f_namajenis" style="color:#088378;float:right;"  >hehehe</font></a></div>
        </div>
        </li>

        <li class="item-content" style="border-bottom:0.5px solid #C8B9C2;">
        <div class="item-inner">
        <div class="item-title"><a href="#" style="color:black;"  id="edit_fproduk" data-kat="produk-nama">Nama Produk
        <font style="color:#088378;float:right;" id="f_nama">hehehe</font></a></div>
        </div>
        </li>
        
        <li class="item-content" style="border-bottom:0.5px solid #C8B9C2;">
        <div class="item-inner">
        <div class="item-title"><a href="#" style="color:black;"  id="edit_fproduk" data-kat="produk-varietas">Varietas Produk
        <font style="color:#088378;float:right;" id="fvarietas"></font></a></div>
        </div>
        </li>
        
        <li class="item-content" style="border-bottom:0.5px solid #C8B9C2;">
        <div class="item-inner">
        <div class="item-title"><a href="#" style="color:black;"  id="edit_fproduk" data-kat="produk-desk">Deskripsi
        <font style="color:#088378;float:right;" id="fdeskripsi"></font></a></div>
        <div class="item-text" id="notedesk">Tambah Keterangan Deskripsi Produk</div>
        </div>
        </li> 

        <li class="item-content" style="border-bottom:0.5px solid #C8B9C2;">
        <div class="item-inner">
        <div class="item-title"><a href="#" style="color:black;"  id="edit_fproduk" data-kat="produk-harga">Harga 
        <font style="color:#088378;float:right;" id="fharga" ></font></a></div>
         <div class="item-text" id="noteharga">Isikan Harga Produk Anda</div>
        </div>
        </li> 

          <li class="item-content" style="border-bottom:0.5px solid #C8B9C2;">
        <div class="item-inner">
        <div class="item-title"><a href="#" style="color:black;"  id="edit_fproduk" data-kat="produk-satqty">Satuan & Qty 
        <font style="color:#088378;float:right;" id="fsatqty" ></font></a></div>
         <div class="item-text" id="notesatuan">Satuan </div>
        </div>
        </li>

          <li class="item-content" style="border-bottom:0.5px solid #C8B9C2;">
        <div class="item-inner">
        <div class="item-title"><a href="#" style="color:black;"  id="edit_fproduk" data-kat="produk-waktu">Masa Lelang 
        <font style="color:#088378;float:right;" id="fwaktu" ></font></a></div>
         <div class="item-text" id="notewaktu">Masa waktu berlaku produk di market </div>
        </div>
        </li>

        
     <li style="display: none;">
            <div class="item-content">
              <div class="item-inner">
                <div class="item-title  label " style="font-size: 14px;">Nama Produk</div>
                <div class="item-input">
                  <input type="text" id="asd" placeholder="Tulis Nama Produk" style="font-size: 14px;" />
                </div>
              </div>
            </div>
          </li>

         
    
        </ul>
      </div>
            <!-- end listblokc -->
  
  </div>
</div>
