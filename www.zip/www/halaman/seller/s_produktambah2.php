<div data-page="s_produktambah2" class="page navbar-fixed ">
  <div class="navbar" style="background-color:#088378;">
    <div class="navbar-inner">
        <div class="left sliding"><a href="#" class="link back icon-only"><i class="icon icon-back"></i></a></div>
        <div class="center"></div>
        <div class="right"> 
          <a href="#" id="pt_next2" style="color:white;margin-right: 1.3em;font-size: 16px;">Selanjutnya</a></div>
    </div>
  </div>
  <div class="page-content" >
       <div class="list-block introtext base-terra" >
         <center>
<!--- ----Foto Lahan---- -->
           <h2 style=" padding-left: 10px;" class="f18"></span>Foto Produk yang ingin dijual</h2>
              <div class="item-content ninety-percent margin-5" style="border-bottom:1px solid #088378;">
                <div class="item-inner" style="">
                    <img class="full-border-base" id="pt_gambar" width="100%" src="img/etc/default_lahan.jpg" alt="">
                </div>
              </div>
                 <div class="item-content ninety-percent margin-5" style="border-bottom:1px solid #088378;min-height:0px;height:40px;">  
                <div class="item-inner" style="min-height:0px;height:30px;margin-left:0px;">
                  <a id="pt_camera" class=" no-transform my-bold" style="width:44%;background-color:#088378;border-radius:50px;color:white;">Camera</a>  <a id="pt_upload" class=" no-transform my-bold" style="width:44%;background-color:#088378;border-radius:50px;color:white;">Upload Dari File</a>
                </div>
              </div>
            </center>
            </div> 
            <!-- end listblokc -->
  
  </div>
</div>
