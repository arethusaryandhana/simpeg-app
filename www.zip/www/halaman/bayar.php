<div data-page="bayar" class="page">
  <div class="navbar header">
    <div class="navbar-inner">
      <div class="left sliding"><a href="#" class="link back icon-only"><i class="fa fa-chevron-left color-black"></i></a></div>
      </div>
  </div>
  <div class="page-content" >
   
    
 <iframe src="https://facebook.com" id='myiframe' style="width:100%; height:100%;">
       
   
  
  </div>
</div>
