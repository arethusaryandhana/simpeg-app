<div data-page="sign-up" class="page">
  <div class="navbar header">
    <div class="navbar-inner">
    </div>
  </div>
  <div class="page-content logins hide-bars-on-scroll own-signup" style="background-color:#eae8e8;background-image: linear-gradient(#eae8e8, white 5%,#eae8e8 95%);">
    <center>
      <div class="logo main col12"  style="background-color:none;">
          <img src="img/icon/logo_TERRA_full_color.svg" alt="">
      </div>
      <div class="clear"></div>
      <form>
        <div class="list-block introtext base-terra" >
          <p> LOGIN MASUK</p>
          <center>
            <!--- ----Username---- -->
            <div class="item-content ninety-percent margin-5" style="border:2px solid #088378;border-radius:10px;min-height:0px;height:40px;">
              <div class="item-media" style="min-height:0px;height:40px;">
                <img src="img/icon/icon_profile_color.svg" width="60%" alt=""> 
              </div>
              <div class="item-inner" style="min-height:0px;height:40px;margin-left:0px;">
                  <input id="usernameLogin" type="text" style="font-size:12px;" placeholder="Username" required="" class="">
              </div>
            </div>
            <!--- ----Password---- -->
            <div class="item-content ninety-percent margin-5" style="border:2px solid #088378;border-radius:10px;min-height:0px;height:40px;">
              <div class="item-media" style="min-height:0px;height:40px;">
                <img src="img/icon/icon_secure_color.svg" width="40%" alt=""> 
              </div>
              <div class="item-inner" style="min-height:0px;height:40px;margin-left:0px;">
                <input id="passwordLogin" type="password" style="font-size:12px;" placeholder="Password Keamanan" required="" class="">
              </div>
            </div>
            <!--- ----ResetPassword---- -->
            <div class="item-content "> 
                <div class="button col-50 no-transform" style="font-size:70%;text-align:left;"></div>
               <p class="button col-50 no-transform" style="font-size:70%;text-align:right;color:#088378;font-weight:normal;">Reset password ?&nbsp;&nbsp;&nbsp;&nbsp;</p>
            </div>
            <!--- ----Buttonmasuk---- -->
            <div  style="padding-top:5%;" >
              <center> 
                <a id="login" class="button button-fill button-raised my-bold" style="font-size:10px;width:50%;background-color:#088378;border-radius:50px;color:white;">MASUK</a>
              </center>
            </div>
            <!--- ----ButtonDaftar---- -->
            <div class="ninety-percent" style="padding-top:10%;border-bottom:1px solid black;">
               <center><p style="font-size:70%;color:black;font-weight:normal;">Atau login menggunakan akun lain</p></center>
            </div>

            <!--- ----ButtonDaftar---- -->
            <div class="ninety-percent  margin-5" style="background-color:#f3122e;border-radius:8px;padding:5px;">
              <img style="vertical-align:middle" src="img/custom/google_plus_icon_white.svg">
              <span style="font-weight:normal;color:white;font-family: 'Uni Sans Thin', sans-serif;font-size:10px;">Login dengan Google</span>
            </div>
            <div class="ninety-percent  margin-5" style="background-color:#0f64aa;border-radius:8px;padding:5px;">
              <img style="vertical-align:middle" src="img/custom/facebook_icon_white.svg">
              <span style="font-weight:normal;color:white;font-family: 'Uni Sans Thin', sans-serif;font-size:10px;">Login dengan Facebook</span>
            </div>
            <div class="my-bottom main row">
                  <div class="button col-50 no-transform" style="font-size:70%;text-align:left;"></div>
                  <a id="redirect-sign-up" class="button col-50 no-transform" style="font-size:70%;text-align:right;color:black;">Daftar baru&nbsp;&nbsp;&nbsp;&nbsp;</a>
            </div>
          </center>
        </div>
      </form>
    </center>
  </div>
</div>
