<?php
  header('Access-Control-Allow-Origin: *'); 
?>
<div data-page="edit" class="page navbar-fixed">
  <div class="navbar " style="background-color:#088378;">
    <div class="navbar-inner">
      <div class="left"><a href="index.html" class="back link icon-only"><i class="icon icon-back"></i></a></div>
      <div class="center" id="editjudul" style="text-transform: none;"></div>
      <div class="right font-12" style="padding-right:5%;" id="editsimpan">Simpan</div>
    </div>
  </div>
  <div class="page-content"> 
    <form>
      <div class="list-block" id="editKonten">
      </div>
    </form>
  </div>
</div> 
