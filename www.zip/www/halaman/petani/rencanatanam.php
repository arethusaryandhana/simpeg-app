<div data-page="rencanatanam" class="page navbar-fixed">
  <div class="navbar" style="background-color:#088378;">
     <div class="navbar-inner">
      <div class="left"><a href="halaman/home.php" class="link icon-only" id="back_rencanatanam"><i class="icon icon-back"></i></a></div>
      <div class="center"><b>Rencana Tanam</b></div>
      <div class="right"><a href="#" class="open-panel link icon-only"><i class="icon icon-bars"></i></a></div>
    </div>
  </div>
   <a href="#" class="floating-button color-purple" id="floatrencana">
    <i class="icon icon-plus"></i>
  </a>
    <div class="toolbar tabbar" style="background-color:#088378;">
        <div class="toolbar-inner"><a href="#tab31" class="button active tab-link">On Progress</a>
          <!-- <a href="#tab32" class="button tab-link">Siap Kirim</a> -->
          <a href="#tab33" class="button tab-link">Done</a></div>
    </div>
  <div class="page-content pull-to-refresh-content" data-ptr-distance="55">
    <div class="pull-to-refresh-layer">
    <div class="preloader"></div>
    <div class="pull-to-refresh-arrow"></div>
  </div>
    

    <style>

</style>

    <div class="tabs-animated-wrap">
    <div class="tabs">
      <div id="tab31" class=" tab page-content active">
        <div class="content-block-title"><i class="fa fa-refresh color-green" aria-hidden="true"></i> Rencana Tanam (Sedang/Akan Datang)</div>
    
     
        <div id="isitanama">
          
        </div>
        
      
      
      <!--     <div class="card facebook-card">
          <div class="card-header no-border">
          <div class="facebook-avatar"><img src="img/padi.jpg" width="60" height="60"></div>
          <div class="facebook-name">1. Ini tanamanku test</div>


          <div class="card-content"> <div class="card-content-inner">keterangan<br/> 21 Maret 2019 - 2093939338 sdsa ini adalah percobaan kalimat ku yang cukup panjang dan memusingkan <br/><a href="#" id="a_popover"> Dokumentasi</a>  </div></div> 
          </div>
          <div class="card-footer">
          <a href="#"></a>
          <a href="#" class="link" style="text-align: center;"><i class="fa fa-plus" aria-hidden="true"></i> Action</a>
          <a href="#"></a>
          </div>
          </div>



 
           <div class="card facebook-card">
          <div class="card-header no-border">
          <div class="facebook-avatar"><img src="img/padi.jpg" width="40" height="40"></div>
          <div class="facebook-name">1 Ini tanamanku asd</div>


          </div>
          <div class="card-content"> <div class="card-content-inner">keterangan<br/><a href="#" data-popover=".popover-about" data-foto="'. $rows['foto'] .'" class="link open-popover" id="a_popover"><i class="fa fa-camera-retro color-blue" aria-hidden="true"></i> Dokumentasi</a></div></div>

          </div> -->


      </div>        <!-- end tab 1 -->

   <!--    <div id="tab32" class="tab page-content" style="display: none;">
              <div class="content-block-title"><i class="fa fa-thumbs-up color-blue" aria-hidden="true"></i> List Penanaman Sukses</div>
    <div class="list-block media-list">
      <ul>
        <div id="isitanamb">
          
        </div>
        
      </ul>
    </div> 
          
        </div> -->
      <div id="tab33" class=" page-content tab">
        <div class="content-block-title"><i class="fa fa-refresh color-green" aria-hidden="true"></i>  List Penanaman Telah Selesai / Gagal</div>
    <div class="list-block media-list">
      <ul>
        <div id="isitanamc">
          
        </div>
        
      </ul>
    </div> 
         
      </div>
    </div>
  </div>
  </div>
      
</div>  
 