<div data-page="Pembelian" class="page navbar-fixed">
    <div class="navbar" style="background-color:#088378;">
    <div class="navbar-inner">
    <div class="left"><a href="halaman/home.php" class="link icon-only" id="back_rencanatanam"><i class="icon icon-back"></i></a></div>
    <div class="center"><b>History Pembelian</b></div>
    <div class="right"><a href="#" class="open-panel link icon-only"><i class="icon icon-bars"></i></a></div>
    </div>
    </div>
    <a href="#" class="floating-button color-purple" id="floatrencana">
    <i class="icon icon-plus"></i>
    </a>
    <div class="toolbar tabbar" style="background-color:#088378;">
    <div class="toolbar-inner"><a href="#tab31" class="button active tab-link">Jasa</a>
    <!-- <a href="#tab32" class="button tab-link">Siap Kirim</a> -->
    <a href="#tab33" class="button tab-link">Komoditas</a></div>
    </div>
    <div class="page-content pull-to-refresh-content" data-ptr-distance="55">
        <div class="pull-to-refresh-layer">
            <div class="preloader"></div>
            <div class="pull-to-refresh-arrow"></div>
        </div>


        <style>

        </style>

        <div class="tabs-animated-wrap">
            <div class="tabs">
            <div id="tab31" class=" tab page-content active">
                <div class="content-block-title">
                   <i class="fa fa-refresh color-green" aria-hidden="true"></i> Rencana Tanam (Sedang/Akan Datang)
                </div>

                <div id="isipembelianjasa">
                </div>

                <div>
                <div class="card facebook-card">
                    <div class="card-footer  dav-minheight dav-pemsukses" style="background-color: #F9BEC0;">
                       <font style="margin:0px auto;"> Menunggu Konfirmasi Kontraktor</font> 
                    </div>
                    <div class="card-header" style="min-height: 0px;font-size: 14px;font-weight: bold;">
                        <font style="font-weight: normal;">21 Juni 2019</font><br/><font>INV/20190627/A/1561628039</font> 
                    </div>
                    <div class="card-header no-border">
                        <div class="facebook-avatar"><img src="img/padi.jpg" width="60" height="60"></div>
                        <div class="facebook-name">T-Iseki Ananta Corp</div>
                        <div class="card-content"> 
                        <div class="card-content-inner f14">Total Tagihan<br/><font class="dav-fharga  tproses" > Rp 1.200.000</font> <br/>
                            Waktu Booking<br/><font class="dav-cterra  tproses" ><i class="fa fa-clock-o dav-cterra"></i> 20-08-2019 20:00:00</font>
                        </div>
                        </div> 
                    </div>
                </div>

                <div class="card facebook-card">
                    <div class="card-footer  dav-minheight dav-pemsukses" style="background-color: #95FF78;">
                       <font style="margin:0px auto;"> Pesanan Selesai <i class="fa fa-check dav-cterra"></i></font> 
                    </div>
                    <div class="card-header" style="min-height: 0px;font-size: 14px;font-weight: bold;">
                        <font style="font-weight: normal;">21 Juni 2019</font><br/><font>INV/20190627/A/1561628039</font> 
                    </div>
                    <div class="card-header no-border">
                        <div class="facebook-avatar"><img src="img/padi.jpg" width="60" height="60"></div>
                        <div class="facebook-name">T-Iseki Ananta Corp</div>
                        <div class="card-content"> 
                        <div class="card-content-inner f14">Total Tagihan<br/><font class="dav-fharga  tproses" > Rp 1.200.000</font> <br/>
                            Waktu Booking<br/><font class="dav-cterra  tproses" ><i class="fa fa-clock-o dav-cterra"></i> 20-08-2019 20:00:00</font>
                        </div>
                        </div> 
                    </div>
                </div>





            </div>        <!-- end tab 1 -->

            <div id="tab33" class=" page-content tab">
                <div class="content-block-title"><i class="fa fa-refresh color-green" aria-hidden="true"></i>  List Penanaman Telah Selesai / Gagal</div>
                <div class="list-block media-list">
                <ul>
                <div id="isitanamc">

                </div>

                </ul>
                </div> 

            </div>
            </div>
        </div>
    </div>

</div>  
 